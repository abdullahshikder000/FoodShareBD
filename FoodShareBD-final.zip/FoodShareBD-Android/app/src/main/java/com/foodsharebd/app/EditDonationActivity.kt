package com.foodsharebd.app

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditDonationActivity : AppCompatActivity() {

    private var donationId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_donation)
        supportActionBar?.hide()

        donationId = intent.getStringExtra(EXTRA_DONATION_ID)
        val donation = donationId?.let { DonationRepository.getById(it) }

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        val etPickupWindow = findViewById<EditText>(R.id.etPickupWindow)
        val etPickupLocation = findViewById<EditText>(R.id.etPickupLocation)

        if (donation != null) {
            findViewById<TextView>(R.id.tvFoodTypeDisplay).text = donation.foodType
            findViewById<TextView>(R.id.tvQuantityDisplay).text = donation.quantity
            findViewById<TextView>(R.id.tvUnitDisplay).text = donation.unit
            etPickupWindow.setText(donation.pickupWindow)
            etPickupLocation.setText(donation.pickupLocation)
            findViewById<View>(R.id.tvLockedCaption).visibility =
                if (donation.status == DonationStatus.PENDING) View.GONE else View.VISIBLE
        }

        findViewById<View>(R.id.btnSaveChanges).setOnClickListener {
            donation?.apply {
                pickupWindow = etPickupWindow.text.toString().trim().ifEmpty { pickupWindow }
                pickupLocation = etPickupLocation.text.toString().trim().ifEmpty { pickupLocation }
            }
            Toast.makeText(this, "Changes saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<View>(R.id.btnCancelDonation).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Cancel Donation")
                .setMessage("Are you sure you want to cancel this donation?")
                .setPositiveButton("Yes") { _, _ ->
                    donationId?.let { DonationRepository.cancel(it) }
                    Toast.makeText(this, "Donation cancelled", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .setNegativeButton("No", null)
                .show()
        }
    }
}
