package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class AvailableDonationsActivity : AppCompatActivity() {

    private lateinit var donationsContainer: LinearLayout
    private lateinit var etSearch: EditText
    private var sortByLargeQty = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_available_donations)
        supportActionBar?.hide()

        donationsContainer = findViewById(R.id.donationsContainer)
        etSearch = findViewById(R.id.etSearch)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.navHome).setOnClickListener { finish() }
        findViewById<View>(R.id.navImpact).setOnClickListener {
            android.widget.Toast.makeText(this, "Impact screen coming soon", android.widget.Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.navProfile).setOnClickListener {
            android.widget.Toast.makeText(this, "Profile screen coming soon", android.widget.Toast.LENGTH_SHORT).show()
        }

        val chipNearby = findViewById<TextView>(R.id.chipNearby)
        val chipExpiring = findViewById<TextView>(R.id.chipExpiring)
        val chipLargeQty = findViewById<TextView>(R.id.chipLargeQty)
        val chips = listOf(chipNearby, chipExpiring, chipLargeQty)

        fun selectChip(chip: TextView) {
            chips.forEach { c ->
                val isSelected = c == chip
                c.setBackgroundResource(if (isSelected) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
                c.setTextColor(
                    ContextCompat.getColor(this, if (isSelected) R.color.primary_green else R.color.text_secondary)
                )
            }
            sortByLargeQty = chip == chipLargeQty
            render()
        }
        chips.forEach { chip -> chip.setOnClickListener { selectChip(chip) } }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val query = etSearch.text.toString().trim().lowercase()
        var donations = DonationRepository.getAvailableDonations().filter { donation ->
            query.isEmpty() ||
                donation.foodType.lowercase().contains(query) ||
                donation.pickupLocation.lowercase().contains(query)
        }
        if (sortByLargeQty) {
            donations = donations.sortedByDescending { it.quantity.toDoubleOrNull() ?: 0.0 }
        }

        donationsContainer.removeAllViews()
        findViewById<View>(R.id.tvEmptyState).visibility = if (donations.isEmpty()) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(this)
        donations.forEach { donation ->
            val row = inflater.inflate(R.layout.item_available_donation_row, donationsContainer, false)
            row.findViewById<TextView>(R.id.tvRowTitle).text = donation.foodType
            row.findViewById<TextView>(R.id.tvRowSubtitle).text =
                "From ${donation.donorName} · ${donation.distanceKm} km"
            row.findViewById<TextView>(R.id.tvRowMatch).text = "+${donation.matchPercent}"
            row.setOnClickListener {
                startActivity(
                    Intent(this, DonationDetailsNgoActivity::class.java)
                        .putExtra(EXTRA_DONATION_ID, donation.id)
                )
            }
            row.findViewById<View>(R.id.btnRowClaim).setOnClickListener {
                val sheet = ClaimConfirmationBottomSheet.newInstance(donation.id)
                sheet.onClaimed = { render() }
                sheet.show(supportFragmentManager, "claim")
            }
            donationsContainer.addView(row)
        }
    }
}
