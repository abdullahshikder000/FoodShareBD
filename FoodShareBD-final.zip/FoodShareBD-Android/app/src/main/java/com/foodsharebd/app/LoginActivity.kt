package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private var passwordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        supportActionBar?.hide()

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnToggle = findViewById<ImageView>(R.id.btnTogglePassword)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }

        btnToggle.setOnClickListener {
            passwordVisible = !passwordVisible
            etPassword.inputType = if (passwordVisible)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            etPassword.setSelection(etPassword.text.length)
            btnToggle.setImageResource(if (passwordVisible) R.drawable.ic_eye_off else R.drawable.ic_eye)
        }

        findViewById<android.widget.TextView>(R.id.btnForgotPassword).setOnClickListener {
            startActivity(Intent(this, ForgotPasswordActivity::class.java))
        }

        findViewById<android.widget.TextView>(R.id.btnGoSignUp).setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }

        findViewById<android.widget.TextView>(R.id.btnLogin).setOnClickListener {
            var valid = true
            if (etEmail.text.toString().trim().isEmpty()) {
                etEmail.error = "Enter your email"
                valid = false
            }
            if (etPassword.text.toString().isEmpty()) {
                etPassword.error = "Enter your password"
                valid = false
            }
            if (valid) {
                startActivity(Intent(this, RoleSelectionActivity::class.java))
                finish()
            }
        }
    }
}
