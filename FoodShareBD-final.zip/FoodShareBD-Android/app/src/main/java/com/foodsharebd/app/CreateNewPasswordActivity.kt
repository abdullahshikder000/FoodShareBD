package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CreateNewPasswordActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_new_password)
        supportActionBar?.hide()

        findViewById<android.widget.ImageView>(R.id.btnBack).setOnClickListener { finish() }

        val etNewPassword = findViewById<EditText>(R.id.etNewPassword)
        findViewById<TextView>(R.id.btnSendCode).setOnClickListener {
            if (etNewPassword.text.toString().length < 4) {
                etNewPassword.error = "Enter a new password"
                return@setOnClickListener
            }
            Toast.makeText(this, "Password updated. Please log in.", Toast.LENGTH_SHORT).show()
            startActivity(
                Intent(this, LoginActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
            finish()
        }
    }
}
