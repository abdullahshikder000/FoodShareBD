package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class DonorDashboardActivity : AppCompatActivity() {

    private lateinit var donationsContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donor_dashboard)
        supportActionBar?.hide()

        donationsContainer = findViewById(R.id.donationsContainer)

        findViewById<View>(R.id.btnPostDonation).setOnClickListener {
            startActivity(Intent(this, AddDonationActivity::class.java))
        }

        findViewById<View>(R.id.btnSeeAll).setOnClickListener {
            startActivity(Intent(this, MyDonationsActivity::class.java))
        }

        findViewById<View>(R.id.btnBell).setOnClickListener {
            Toast.makeText(this, "No new notifications", Toast.LENGTH_SHORT).show()
        }

        findViewById<View>(R.id.navDonations).setOnClickListener {
            startActivity(Intent(this, MyDonationsActivity::class.java))
        }
        findViewById<View>(R.id.navImpact).setOnClickListener {
            Toast.makeText(this, "Impact screen coming soon", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.navProfile).setOnClickListener {
            Toast.makeText(this, "Profile screen coming soon", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        renderRecentDonations()
    }

    private fun renderRecentDonations() {
        val donations = DonationRepository.getDonorDonations()
        findViewById<TextView>(R.id.tvStatDonations).text = donations.size.toString()

        donationsContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        donations.take(3).forEach { donation ->
            val row = inflater.inflate(R.layout.item_donation_row, donationsContainer, false)
            row.findViewById<TextView>(R.id.tvRowTitle).text = donation.foodType
            row.findViewById<TextView>(R.id.tvRowSubtitle).text = donation.quantityLabel
            val badge = row.findViewById<TextView>(R.id.tvRowBadge)
            applyStatusBadge(badge, donation.status)
            row.setOnClickListener {
                startActivity(
                    Intent(this, DonationDetailsActivity::class.java)
                        .putExtra(EXTRA_DONATION_ID, donation.id)
                )
            }
            donationsContainer.addView(row)
        }
    }

    private fun applyStatusBadge(badge: TextView, status: DonationStatus) {
        val (bg, textColor, label) = when (status) {
            DonationStatus.PENDING -> Triple(R.drawable.bg_badge_orange, R.color.badge_orange_text, "Pending")
            DonationStatus.CLAIMED -> Triple(R.drawable.bg_badge_blue, R.color.badge_blue_text, "Claimed")
            DonationStatus.PICKED_UP -> Triple(R.drawable.bg_badge_green, R.color.badge_green_text, "Picked up")
        }
        badge.setBackgroundResource(bg)
        badge.setTextColor(ContextCompat.getColor(this, textColor))
        badge.text = label
    }
}
