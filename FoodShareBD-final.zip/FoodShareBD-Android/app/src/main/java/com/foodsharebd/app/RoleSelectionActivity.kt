package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RoleSelectionActivity : AppCompatActivity() {

    private var selectedRole = "donor"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_role_selection)
        supportActionBar?.hide()

        val cardDonor = findViewById<LinearLayout>(R.id.cardDonor)
        val cardNgo = findViewById<LinearLayout>(R.id.cardNgo)
        val btnBack = findViewById<View>(R.id.btnBack)
        val btnContinue = findViewById<TextView>(R.id.btnContinue)

        fun selectRole(role: String) {
            selectedRole = role
            cardDonor.setBackgroundResource(
                if (role == "donor") R.drawable.bg_card_selected_green else R.drawable.bg_card_default
            )
            cardNgo.setBackgroundResource(
                if (role == "ngo") R.drawable.bg_card_selected_green else R.drawable.bg_card_default
            )
        }

        cardDonor.setOnClickListener { selectRole("donor") }
        cardNgo.setOnClickListener { selectRole("ngo") }
        // Admin card is intentionally not clickable - provisioned internally only.

        btnBack.setOnClickListener { finish() }

        btnContinue.setOnClickListener {
            val target = if (selectedRole == "ngo") NgoDashboardActivity::class.java else DonorDashboardActivity::class.java
            startActivity(Intent(this, target))
        }
    }
}
