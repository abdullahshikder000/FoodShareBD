package com.foodsharebd.app

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class AddDonationActivity : AppCompatActivity() {

    private var selectedCondition = FoodCondition.FRESH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_donation)
        supportActionBar?.hide()

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        val spinnerUnit = findViewById<Spinner>(R.id.spinnerUnit)
        spinnerUnit.adapter = ArrayAdapter.createFromResource(
            this, R.array.unit_options, android.R.layout.simple_spinner_dropdown_item
        )

        val chipFresh = findViewById<TextView>(R.id.chipFresh)
        val chipCooked = findViewById<TextView>(R.id.chipCooked)
        val chipNearExpiry = findViewById<TextView>(R.id.chipNearExpiry)
        val chips = listOf(chipFresh to FoodCondition.FRESH, chipCooked to FoodCondition.COOKED, chipNearExpiry to FoodCondition.NEAR_EXPIRY)

        fun selectCondition(chip: TextView, condition: FoodCondition) {
            selectedCondition = condition
            chips.forEach { (c, _) ->
                val isSelected = c == chip
                c.setBackgroundResource(if (isSelected) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
                c.setTextColor(
                    ContextCompat.getColor(this, if (isSelected) R.color.primary_green else R.color.text_secondary)
                )
            }
        }
        chips.forEach { (chip, condition) -> chip.setOnClickListener { selectCondition(chip, condition) } }

        val etFoodType = findViewById<EditText>(R.id.etFoodType)
        val etDescription = findViewById<EditText>(R.id.etDescription)
        val etQuantity = findViewById<EditText>(R.id.etQuantity)
        val etPickupWindow = findViewById<EditText>(R.id.etPickupWindow)
        val etLocation = findViewById<EditText>(R.id.etPickupLocation)

        findViewById<View>(R.id.btnSubmit).setOnClickListener {
            val foodType = etFoodType.text.toString().trim()
            val quantity = etQuantity.text.toString().trim()
            val location = etLocation.text.toString().trim()
            val pickupWindow = etPickupWindow.text.toString().trim()

            if (foodType.isEmpty()) {
                etFoodType.error = "Enter a food type"
                return@setOnClickListener
            }
            if (quantity.isEmpty()) {
                etQuantity.error = "Enter quantity"
                return@setOnClickListener
            }
            if (location.isEmpty()) {
                etLocation.error = "Enter pickup location"
                return@setOnClickListener
            }

            val donation = Donation(
                id = DonationRepository.nextIdForNewDonation(),
                foodType = foodType,
                description = etDescription.text.toString().trim(),
                quantity = quantity,
                unit = spinnerUnit.selectedItem?.toString() ?: "kg",
                condition = selectedCondition,
                pickupWindow = pickupWindow.ifEmpty { "Today" },
                pickupLocation = location,
                donorName = DonationRepository.CURRENT_DONOR_NAME,
                postedAtMillis = System.currentTimeMillis(),
                status = DonationStatus.PENDING,
                matchPercent = (70..97).random(),
                distanceKm = (10..40).random() / 10.0
            )
            DonationRepository.add(donation)

            Toast.makeText(this, "Donation posted!", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        }
    }
}
