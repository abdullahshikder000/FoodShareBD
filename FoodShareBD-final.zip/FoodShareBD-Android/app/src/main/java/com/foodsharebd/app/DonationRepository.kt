package com.foodsharebd.app

/**
 * Simple in-memory, process-lifetime store. There's no backend in this build, so this
 * object is the single source of truth both the Donor and NGO activities read from and
 * write to, which is what lets a posted donation actually show up on the NGO side and a
 * claim actually show up back on the donor side.
 */
object DonationRepository {

    const val CURRENT_DONOR_NAME = "Restaurant ABC"
    const val CURRENT_NGO_NAME = "Hope Shelter Trust"

    private val donations = mutableListOf<Donation>()
    private var nextId = 1
    private fun newId(): String = (nextId++).toString()

    init {
        val now = System.currentTimeMillis()
        donations.add(
            Donation(
                id = newId(), foodType = "Cooked Rice & Curry", quantity = "12", unit = "kg",
                condition = FoodCondition.FRESH, pickupWindow = "Today, 6:00–8:00 PM",
                pickupLocation = "Gulshan-2, Dhaka", donorName = CURRENT_DONOR_NAME,
                postedAtMillis = now - 25 * 60 * 1000L, status = DonationStatus.CLAIMED,
                matchPercent = 95, distanceKm = 1.2, claimedByOrg = CURRENT_NGO_NAME,
                claimedByContact = "Md. Karim (Volunteer)", claimedByNote = "We'll arrive by 6:15 PM"
            )
        )
        donations.add(
            Donation(
                id = newId(), foodType = "Bakery Items", quantity = "8", unit = "kg",
                condition = FoodCondition.FRESH, pickupWindow = "Today, 4:00–6:00 PM",
                pickupLocation = "Banani, Dhaka", donorName = CURRENT_DONOR_NAME,
                postedAtMillis = now - 90 * 60 * 1000L, status = DonationStatus.PENDING,
                matchPercent = 88, distanceKm = 2.4
            )
        )
        donations.add(
            Donation(
                id = newId(), foodType = "Fresh Produce", quantity = "10", unit = "kg",
                condition = FoodCondition.FRESH, pickupWindow = "Today, 5:00–7:00 PM",
                pickupLocation = "Green Grocers, Dhaka", donorName = "Green Grocers",
                postedAtMillis = now - 40 * 60 * 1000L, status = DonationStatus.PENDING,
                matchPercent = 81, distanceKm = 3.1
            )
        )
        donations.add(
            Donation(
                id = newId(), foodType = "Fresh Vegetables", quantity = "20", unit = "kg",
                condition = FoodCondition.FRESH, pickupWindow = "Yesterday, 5:00–7:00 PM",
                pickupLocation = "Gulshan-2, Dhaka", donorName = CURRENT_DONOR_NAME,
                postedAtMillis = now - 24 * 60 * 60 * 1000L, status = DonationStatus.PICKED_UP,
                matchPercent = 81, claimedByOrg = "Hope Shelter Trust"
            )
        )
        donations.add(
            Donation(
                id = newId(), foodType = "Mixed Produce", quantity = "15", unit = "kg",
                condition = FoodCondition.FRESH, pickupWindow = "Yesterday, 3:00–5:00 PM",
                pickupLocation = "Gulshan-2, Dhaka", donorName = CURRENT_DONOR_NAME,
                postedAtMillis = now - 26 * 60 * 60 * 1000L, status = DonationStatus.PICKED_UP,
                matchPercent = 76, claimedByOrg = "Green Grocers Relief"
            )
        )
    }

    /** All donations from the current donor, newest first. */
    fun getDonorDonations(): List<Donation> =
        donations.filter { it.donorName == CURRENT_DONOR_NAME }.sortedByDescending { it.postedAtMillis }

    /** Donations any NGO can still claim, best match first. */
    fun getAvailableDonations(): List<Donation> =
        donations.filter { it.status == DonationStatus.PENDING }.sortedByDescending { it.matchPercent }

    fun getById(id: String): Donation? = donations.find { it.id == id }

    fun add(donation: Donation) {
        donations.add(0, donation)
    }

    fun nextIdForNewDonation(): String = newId()

    fun claim(id: String, orgName: String, contact: String, note: String) {
        getById(id)?.apply {
            status = DonationStatus.CLAIMED
            claimedByOrg = orgName
            claimedByContact = contact
            claimedByNote = note
        }
    }

    fun confirmPickedUp(id: String) {
        getById(id)?.status = DonationStatus.PICKED_UP
    }

    fun cancel(id: String) {
        donations.removeAll { it.id == id }
    }
}
