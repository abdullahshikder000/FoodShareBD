package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class DonationDetailsActivity : AppCompatActivity() {

    private var donationId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation_details)
        supportActionBar?.hide()

        donationId = intent.getStringExtra(EXTRA_DONATION_ID)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<View>(R.id.btnConfirmPickup).setOnClickListener {
            donationId?.let { DonationRepository.confirmPickedUp(it) }
            Toast.makeText(this, "Pickup confirmed!", Toast.LENGTH_SHORT).show()
            finish()
        }

        val btnMore = findViewById<View>(R.id.btnMore)
        btnMore.setOnClickListener {
            val popup = PopupMenu(this, btnMore)
            popup.menuInflater.inflate(R.menu.menu_donation_options, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.action_edit -> {
                        startActivity(
                            Intent(this, EditDonationActivity::class.java)
                                .putExtra(EXTRA_DONATION_ID, donationId)
                        )
                        true
                    }
                    R.id.action_cancel -> {
                        donationId?.let { DonationRepository.cancel(it) }
                        Toast.makeText(this, "Donation cancelled", Toast.LENGTH_SHORT).show()
                        finish()
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val donation = donationId?.let { DonationRepository.getById(it) } ?: return

        findViewById<TextView>(R.id.tvTitle).text = donation.foodType
        findViewById<TextView>(R.id.tvPostedTime).text = donation.postedAgoText()
        findViewById<TextView>(R.id.tvQtyCondition).text =
            "${donation.quantityLabel} · ${donation.condition.label}"
        findViewById<TextView>(R.id.tvPickupTime).text = "Pickup: ${donation.pickupWindow}"
        findViewById<TextView>(R.id.tvLocation).text = donation.pickupLocation

        val badge = findViewById<TextView>(R.id.tvStatusBadge)
        val (bg, textColor) = when (donation.status) {
            DonationStatus.PENDING -> R.drawable.bg_badge_orange to R.color.badge_orange_text
            DonationStatus.CLAIMED -> R.drawable.bg_badge_blue to R.color.badge_blue_text
            DonationStatus.PICKED_UP -> R.drawable.bg_badge_green to R.color.badge_green_text
        }
        badge.setBackgroundResource(bg)
        badge.setTextColor(ContextCompat.getColor(this, textColor))
        badge.text = donation.statusLabel()

        val hasMatch = donation.claimedByOrg != null
        findViewById<View>(R.id.tvMatchedNgoLabel).visibility = if (hasMatch) View.VISIBLE else View.GONE
        findViewById<View>(R.id.matchedNgoCard).visibility = if (hasMatch) View.VISIBLE else View.GONE
        if (hasMatch) {
            findViewById<TextView>(R.id.tvMatchedNgoName).text = donation.claimedByOrg
            findViewById<TextView>(R.id.tvMatchedNgoMeta).text =
                "${donation.distanceKm} km away · ★ 4.9"
        }

        findViewById<View>(R.id.btnConfirmPickup).visibility =
            if (donation.status == DonationStatus.CLAIMED) View.VISIBLE else View.GONE
    }
}
