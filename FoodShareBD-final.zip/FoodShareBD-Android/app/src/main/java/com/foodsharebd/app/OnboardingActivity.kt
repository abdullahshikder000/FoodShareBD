package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2

class OnboardingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)
        supportActionBar?.hide()

        val viewPager = findViewById<ViewPager2>(R.id.viewPager)

        val greenBg = ContextCompat.getColor(this, R.color.green_light_bg)
        val greenAccent = ContextCompat.getColor(this, R.color.primary_green)
        val orangeBg = ContextCompat.getColor(this, R.color.badge_orange_bg)
        val orangeAccent = ContextCompat.getColor(this, R.color.accent_orange)

        val items = listOf(
            OnboardingItem(
                title = "List Surplus Food in Seconds",
                description = "Restaurants, hotels and grocery stores post surplus food before it spoils — takes under a minute.",
                imageRes = R.drawable.ic_bag,
                cardBgColor = greenBg,
                accentColor = greenAccent,
                buttonText = "Next"
            ),
            OnboardingItem(
                title = "Feed Communities That Need It",
                description = "NGOs and volunteers get a live feed of nearby donations, with pickup windows and directions.",
                imageRes = R.drawable.ic_home,
                cardBgColor = greenBg,
                accentColor = greenAccent,
                buttonText = "Next"
            ),
            OnboardingItem(
                title = "Smart Matching, Zero Guesswork",
                description = "Our ranking engine suggests the best NGO for every donation instantly, so food moves fast.",
                imageRes = R.drawable.ic_network,
                cardBgColor = orangeBg,
                accentColor = orangeAccent,
                buttonText = "Get Started"
            )
        )

        fun goToLogin() {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        viewPager.adapter = OnboardingAdapter(items, object : OnboardingAdapter.OnActionListener {
            override fun onActionClick(position: Int) {
                if (position < items.size - 1) {
                    viewPager.currentItem = position + 1
                } else {
                    goToLogin()
                }
            }

            override fun onSkipClick() {
                goToLogin()
            }
        })
    }
}
