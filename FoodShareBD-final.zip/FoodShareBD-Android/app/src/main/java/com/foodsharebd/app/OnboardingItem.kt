package com.foodsharebd.app

data class OnboardingItem(
    val title: String,
    val description: String,
    val imageRes: Int,
    val cardBgColor: Int,
    val accentColor: Int,
    val buttonText: String
)
