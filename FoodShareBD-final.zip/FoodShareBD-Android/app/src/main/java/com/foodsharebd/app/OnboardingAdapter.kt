package com.foodsharebd.app

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class OnboardingAdapter(
    private val items: List<OnboardingItem>,
    private val listener: OnActionListener
) : RecyclerView.Adapter<OnboardingAdapter.OnboardingViewHolder>() {

    interface OnActionListener {
        fun onActionClick(position: Int)
        fun onSkipClick()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OnboardingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_onboarding, parent, false)
        return OnboardingViewHolder(view)
    }

    override fun onBindViewHolder(holder: OnboardingViewHolder, position: Int) {
        holder.bind(items[position], position)
    }

    override fun getItemCount(): Int = items.size

    inner class OnboardingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val tvTitle = itemView.findViewById<TextView>(R.id.tvTitle)
        private val tvDescription = itemView.findViewById<TextView>(R.id.tvDescription)
        private val ivOnboarding = itemView.findViewById<ImageView>(R.id.ivOnboarding)
        private val cvImageContainer = itemView.findViewById<FrameLayout>(R.id.cvImageContainer)
        private val btnAction = itemView.findViewById<TextView>(R.id.btnAction)
        private val btnSkip = itemView.findViewById<TextView>(R.id.btnSkip)
        private val indicator0 = itemView.findViewById<ImageView>(R.id.indicator0)
        private val indicator1 = itemView.findViewById<ImageView>(R.id.indicator1)
        private val indicator2 = itemView.findViewById<ImageView>(R.id.indicator2)

        fun bind(item: OnboardingItem, position: Int) {
            tvTitle.text = item.title
            tvDescription.text = item.description
            ivOnboarding.setImageResource(item.imageRes)
            ivOnboarding.imageTintList = ColorStateList.valueOf(item.accentColor)
            cvImageContainer.backgroundTintList = ColorStateList.valueOf(item.cardBgColor)
            btnAction.text = item.buttonText
            btnAction.backgroundTintList = ColorStateList.valueOf(item.accentColor)

            val indicators = listOf(indicator0, indicator1, indicator2)
            indicators.forEachIndexed { index, dot ->
                dot.setImageResource(
                    if (index == position) R.drawable.bg_dot_green else R.drawable.bg_dot_inactive
                )
                if (index == position && position == items.size - 1) {
                    dot.setImageResource(R.drawable.bg_dot_orange)
                }
            }

            btnSkip.visibility = if (position == items.size - 1) View.GONE else View.VISIBLE

            btnAction.setOnClickListener { listener.onActionClick(bindingAdapterPosition) }
            btnSkip.setOnClickListener { listener.onSkipClick() }
        }
    }
}
