package com.foodsharebd.app

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DonationDetailsNgoActivity : AppCompatActivity() {

    private var donationId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation_details_ngo)
        supportActionBar?.hide()

        donationId = intent.getStringExtra(EXTRA_DONATION_ID)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<View>(R.id.btnClaim).setOnClickListener {
            val id = donationId ?: return@setOnClickListener
            val sheet = ClaimConfirmationBottomSheet.newInstance(id)
            sheet.onClaimed = { finish() }
            sheet.show(supportFragmentManager, "claim")
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val donation = donationId?.let { DonationRepository.getById(it) } ?: return

        findViewById<TextView>(R.id.tvTitle).text = donation.foodType
        findViewById<TextView>(R.id.tvPostedTime).text = donation.postedAgoText()
        findViewById<TextView>(R.id.tvMatchPercent).text = "+ ${donation.matchPercent}% Match"
        findViewById<TextView>(R.id.tvTagDistance).text = "${donation.distanceKm} km away"
        findViewById<TextView>(R.id.tvDonorName).text = donation.donorName
        findViewById<TextView>(R.id.tvQtyCondition).text =
            "${donation.quantityLabel} · ${donation.condition.label}"
        findViewById<TextView>(R.id.tvPickupTime).text = "Pickup: ${donation.pickupWindow}"
        findViewById<TextView>(R.id.tvLocation).text = donation.pickupLocation

        val claimButton = findViewById<TextView>(R.id.btnClaim)
        if (donation.status == DonationStatus.PENDING) {
            claimButton.visibility = View.VISIBLE
        } else {
            claimButton.visibility = View.VISIBLE
            claimButton.text = "Already Claimed"
            claimButton.isEnabled = false
            claimButton.alpha = 0.5f
        }
    }
}
