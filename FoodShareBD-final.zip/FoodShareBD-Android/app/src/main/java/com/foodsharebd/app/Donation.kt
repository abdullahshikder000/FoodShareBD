package com.foodsharebd.app

const val EXTRA_DONATION_ID = "extra_donation_id"

enum class DonationStatus { PENDING, CLAIMED, PICKED_UP }

enum class FoodCondition(val label: String) {
    FRESH("Fresh"),
    COOKED("Cooked"),
    NEAR_EXPIRY("Near expiry")
}

/**
 * A single food donation. Shared between the Donor side (post/edit/track) and the
 * NGO side (browse/claim) via [DonationRepository] so both dashboards reflect the
 * same in-memory data.
 */
data class Donation(
    val id: String,
    var foodType: String,
    var description: String = "",
    var quantity: String,
    var unit: String,
    var condition: FoodCondition,
    var pickupWindow: String,
    var pickupLocation: String,
    val donorName: String,
    val postedAtMillis: Long,
    var status: DonationStatus,
    var matchPercent: Int = 80,
    var distanceKm: Double = 1.5,
    var claimedByOrg: String? = null,
    var claimedByContact: String? = null,
    var claimedByNote: String? = null
) {
    val quantityLabel: String get() = "$quantity $unit"

    fun postedAgoText(): String {
        val diffMin = (System.currentTimeMillis() - postedAtMillis) / 60000
        return when {
            diffMin < 1 -> "Posted just now"
            diffMin < 60 -> "Posted $diffMin min ago"
            diffMin < 60 * 24 -> "Posted ${diffMin / 60}h ago"
            else -> "Posted ${diffMin / (60 * 24)}d ago"
        }
    }

    fun statusLabel(): String = when (status) {
        DonationStatus.PENDING -> "Pending"
        DonationStatus.CLAIMED -> "Claimed"
        DonationStatus.PICKED_UP -> "Picked up"
    }
}
