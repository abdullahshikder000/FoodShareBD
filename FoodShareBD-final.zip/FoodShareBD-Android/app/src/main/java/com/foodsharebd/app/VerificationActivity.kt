package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class VerificationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verification)
        supportActionBar?.hide()

        findViewById<android.widget.ImageView>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<TextView>(R.id.btnResend).setOnClickListener {
            Toast.makeText(this, "Code resent", Toast.LENGTH_SHORT).show()
        }

        val etCode = findViewById<EditText>(R.id.etCode)
        findViewById<TextView>(R.id.btnSendCode).setOnClickListener {
            if (etCode.text.toString().trim().length < 4) {
                etCode.error = "Enter the code"
                return@setOnClickListener
            }
            startActivity(Intent(this, CreateNewPasswordActivity::class.java))
        }
    }
}
