package com.foodsharebd.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class ClaimConfirmationBottomSheet : BottomSheetDialogFragment() {

    /** Simple host callback so the underlying list can refresh after a successful claim. */
    var onClaimed: (() -> Unit)? = null

    companion object {
        private const val ARG_DONATION_ID = "arg_donation_id"

        fun newInstance(donationId: String): ClaimConfirmationBottomSheet {
            val fragment = ClaimConfirmationBottomSheet()
            fragment.arguments = Bundle().apply { putString(ARG_DONATION_ID, donationId) }
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.bottomsheet_confirm_claim, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val donationId = arguments?.getString(ARG_DONATION_ID)
        val donation = donationId?.let { DonationRepository.getById(it) }

        view.findViewById<TextView>(R.id.tvClaimSubtitle).text =
            if (donation != null) "${donation.foodType} · ${donation.quantityLabel} · ${donation.donorName}"
            else ""

        val etPickerName = view.findViewById<EditText>(R.id.etPickerName)
        val etContactNumber = view.findViewById<EditText>(R.id.etContactNumber)
        val etNote = view.findViewById<EditText>(R.id.etNote)

        view.findViewById<View>(R.id.btnCancelClaim).setOnClickListener { dismiss() }

        view.findViewById<View>(R.id.btnConfirmClaim).setOnClickListener {
            if (donationId == null) {
                dismiss()
                return@setOnClickListener
            }
            val pickerName = etPickerName.text.toString().trim()
            val contactNumber = etContactNumber.text.toString().trim()
            if (pickerName.isEmpty()) {
                etPickerName.error = "Enter who's picking this up"
                return@setOnClickListener
            }
            if (contactNumber.isEmpty()) {
                etContactNumber.error = "Enter a contact number"
                return@setOnClickListener
            }

            DonationRepository.claim(
                id = donationId,
                orgName = DonationRepository.CURRENT_NGO_NAME,
                contact = "$pickerName ($contactNumber)",
                note = etNote.text.toString().trim()
            )
            Toast.makeText(requireContext(), "Claim confirmed!", Toast.LENGTH_SHORT).show()
            onClaimed?.invoke()
            dismiss()
        }
    }
}
