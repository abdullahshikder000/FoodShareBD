package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MyDonationsActivity : AppCompatActivity() {

    private lateinit var donationsContainer: LinearLayout
    private var selectedFilterIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_donations)
        supportActionBar?.hide()

        donationsContainer = findViewById(R.id.donationsContainer)

        val chipAll = findViewById<TextView>(R.id.chipAll)
        val chipPending = findViewById<TextView>(R.id.chipPending)
        val chipClaimed = findViewById<TextView>(R.id.chipClaimed)
        val chipPickedUp = findViewById<TextView>(R.id.chipPickedUp)
        val chips = listOf(chipAll, chipPending, chipClaimed, chipPickedUp)

        fun selectFilter(index: Int) {
            selectedFilterIndex = index
            chips.forEachIndexed { i, chip ->
                val isSelected = i == index
                chip.setBackgroundResource(if (isSelected) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
                chip.setTextColor(
                    ContextCompat.getColor(this, if (isSelected) R.color.primary_green else R.color.text_secondary)
                )
            }
            renderDonations()
        }
        chips.forEachIndexed { i, chip -> chip.setOnClickListener { selectFilter(i) } }

        findViewById<View>(R.id.btnFab).setOnClickListener {
            startActivity(Intent(this, AddDonationActivity::class.java))
        }

        findViewById<View>(R.id.navHome).setOnClickListener { finish() }
        findViewById<View>(R.id.navImpact).setOnClickListener {
            Toast.makeText(this, "Impact screen coming soon", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.navProfile).setOnClickListener {
            Toast.makeText(this, "Profile screen coming soon", Toast.LENGTH_SHORT).show()
        }

        findViewById<View>(R.id.btnFilter).setOnClickListener {
            Toast.makeText(this, "Use the filter chips below to sort", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        renderDonations()
    }

    private fun renderDonations() {
        val all = DonationRepository.getDonorDonations()
        val filtered = when (selectedFilterIndex) {
            1 -> all.filter { it.status == DonationStatus.PENDING }
            2 -> all.filter { it.status == DonationStatus.CLAIMED }
            3 -> all.filter { it.status == DonationStatus.PICKED_UP }
            else -> all
        }

        donationsContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        filtered.forEach { donation ->
            val row = inflater.inflate(R.layout.item_donation_row, donationsContainer, false)
            row.findViewById<TextView>(R.id.tvRowTitle).text = donation.foodType
            row.findViewById<TextView>(R.id.tvRowSubtitle).text =
                "${donation.quantityLabel} · ${donation.pickupWindow}"
            val badge = row.findViewById<TextView>(R.id.tvRowBadge)
            applyStatusBadge(badge, donation.status)
            row.setOnClickListener {
                startActivity(
                    Intent(this, DonationDetailsActivity::class.java)
                        .putExtra(EXTRA_DONATION_ID, donation.id)
                )
            }
            donationsContainer.addView(row)
        }
    }

    private fun applyStatusBadge(badge: TextView, status: DonationStatus) {
        val (bg, textColor, label) = when (status) {
            DonationStatus.PENDING -> Triple(R.drawable.bg_badge_orange, R.color.badge_orange_text, "Pending")
            DonationStatus.CLAIMED -> Triple(R.drawable.bg_badge_blue, R.color.badge_blue_text, "Claimed")
            DonationStatus.PICKED_UP -> Triple(R.drawable.bg_badge_green, R.color.badge_green_text, "Picked up")
        }
        badge.setBackgroundResource(bg)
        badge.setTextColor(ContextCompat.getColor(this, textColor))
        badge.text = label
    }
}
