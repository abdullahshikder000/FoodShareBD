package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ForgotPasswordActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        supportActionBar?.hide()

        findViewById<android.widget.ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.btnBackToLogin).setOnClickListener { finish() }

        val etEmail = findViewById<EditText>(R.id.etEmail)
        findViewById<TextView>(R.id.btnSendCode).setOnClickListener {
            if (etEmail.text.toString().trim().isEmpty()) {
                etEmail.error = "Enter your email"
                return@setOnClickListener
            }
            startActivity(Intent(this, VerificationActivity::class.java))
        }
    }
}
