package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class SignUpActivity : AppCompatActivity() {

    private var isNgoRole = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
        supportActionBar?.hide()

        findViewById<android.widget.ImageView>(R.id.btnBack).setOnClickListener { finish() }

        val tvRoleBadge = findViewById<TextView>(R.id.tvRoleBadge)
        val tvOrgLabel = findViewById<TextView>(R.id.tvOrgLabel)
        val etOrgName = findViewById<EditText>(R.id.etOrgName)

        fun updateRoleUi() {
            if (isNgoRole) {
                tvRoleBadge.text = "NGO / Recipient"
                tvRoleBadge.setBackgroundResource(R.drawable.bg_badge_blue)
                tvRoleBadge.setTextColor(ContextCompat.getColor(this, R.color.badge_blue_text))
                tvOrgLabel.text = "Organization name"
                etOrgName.hint = "Hope Shelter Trust"
            } else {
                tvRoleBadge.text = "Donor"
                tvRoleBadge.setBackgroundResource(R.drawable.bg_badge_green)
                tvRoleBadge.setTextColor(ContextCompat.getColor(this, R.color.badge_green_text))
                tvOrgLabel.text = "Business / Restaurant name"
                etOrgName.hint = "Restaurant ABC"
            }
        }

        findViewById<TextView>(R.id.btnChangeRole).setOnClickListener {
            isNgoRole = !isNgoRole
            updateRoleUi()
        }

        findViewById<TextView>(R.id.btnGoLogin).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val etConfirmPassword = findViewById<EditText>(R.id.etConfirmPassword)
        val cbAgree = findViewById<CheckBox>(R.id.cbAgree)

        findViewById<TextView>(R.id.btnCreateAccount).setOnClickListener {
            var valid = true
            if (etOrgName.text.toString().trim().isEmpty()) {
                etOrgName.error = "Required"
                valid = false
            }
            if (etEmail.text.toString().trim().isEmpty()) {
                etEmail.error = "Required"
                valid = false
            }
            if (etPassword.text.toString().length < 4) {
                etPassword.error = "Too short"
                valid = false
            }
            if (etConfirmPassword.text.toString() != etPassword.text.toString()) {
                etConfirmPassword.error = "Doesn't match"
                valid = false
            }
            if (!cbAgree.isChecked) {
                android.widget.Toast.makeText(this, "Please agree to the Terms of Service", android.widget.Toast.LENGTH_SHORT).show()
                valid = false
            }
            if (!valid) return@setOnClickListener

            val target = if (isNgoRole) NgoDashboardActivity::class.java else DonorDashboardActivity::class.java
            startActivity(Intent(this, target))
            finish()
        }
    }
}
