package com.foodsharebd.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class NgoDashboardActivity : AppCompatActivity() {

    private lateinit var donationsContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ngo_dashboard)
        supportActionBar?.hide()

        donationsContainer = findViewById(R.id.donationsContainer)

        findViewById<View>(R.id.btnBrowse).setOnClickListener {
            startActivity(Intent(this, AvailableDonationsActivity::class.java))
        }
        findViewById<View>(R.id.btnSeeAll).setOnClickListener {
            startActivity(Intent(this, AvailableDonationsActivity::class.java))
        }
        findViewById<View>(R.id.navBrowse).setOnClickListener {
            startActivity(Intent(this, AvailableDonationsActivity::class.java))
        }
        findViewById<View>(R.id.btnBell).setOnClickListener {
            Toast.makeText(this, "No new notifications", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.navImpact).setOnClickListener {
            Toast.makeText(this, "Impact screen coming soon", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.navProfile).setOnClickListener {
            Toast.makeText(this, "Profile screen coming soon", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        renderNearbyDonations()
    }

    private fun renderNearbyDonations() {
        val available = DonationRepository.getAvailableDonations()
        findViewById<TextView>(R.id.tvStatPickups).text =
            DonationRepository.getDonorDonations().count { it.status == DonationStatus.PICKED_UP }.toString()

        donationsContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        available.take(3).forEach { donation ->
            val row = inflater.inflate(R.layout.item_available_donation_row, donationsContainer, false)
            bindAvailableRow(row, donation)
            donationsContainer.addView(row)
        }
    }

    private fun bindAvailableRow(row: View, donation: Donation) {
        row.findViewById<TextView>(R.id.tvRowTitle).text = donation.foodType
        row.findViewById<TextView>(R.id.tvRowSubtitle).text =
            "From ${donation.donorName} · ${donation.distanceKm} km"
        row.findViewById<TextView>(R.id.tvRowMatch).text = "+${donation.matchPercent}"

        row.setOnClickListener {
            startActivity(
                Intent(this, DonationDetailsNgoActivity::class.java)
                    .putExtra(EXTRA_DONATION_ID, donation.id)
            )
        }
        row.findViewById<View>(R.id.btnRowClaim).setOnClickListener {
            val sheet = ClaimConfirmationBottomSheet.newInstance(donation.id)
            sheet.onClaimed = { renderNearbyDonations() }
            sheet.show(supportFragmentManager, "claim")
        }
    }
}
